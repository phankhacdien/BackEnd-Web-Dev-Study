package fa.trainning.controller.memberServlet;

import fa.trainning.entities.Member;
import fa.trainning.services.MemberService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

@WebServlet(name = "ServletMemberRegister", value = "/ServletMemberRegister")
public class ServletMemberRegister extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (MemberService memberService = new MemberService()) {
            String user_name = request.getParameter("user_name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            Member member = new Member(user_name, email, password);

            try{
                if (memberService.getMemberByEmailService(email)){
                    String errorEmail = "Email existed!";
                    request.setAttribute("errorEmail", errorEmail);
                    request.setAttribute("member", member);
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                } else if (memberService.registerMemberService(member)){
                    RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
                    dispatcher.forward(request, response);
                }
                else {
                    request.setAttribute("errorAdd", true);
                    request.getRequestDispatcher("register.jsp").forward(request, response);
                }
            } catch (SQLException throwables) {
                request.setAttribute("errorSQL", true);
                request.setAttribute("member", member);
                request.getRequestDispatcher("register.jsp").forward(request, response);
                throwables.printStackTrace();
            } catch (ParseException | ClassNotFoundException | ServletException | IOException e) {
                e.printStackTrace();
            }
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }
}
