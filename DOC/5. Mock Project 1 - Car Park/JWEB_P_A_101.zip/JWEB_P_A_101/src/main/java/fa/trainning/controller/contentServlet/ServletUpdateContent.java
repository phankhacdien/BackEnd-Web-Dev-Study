package fa.trainning.controller.contentServlet;

import fa.trainning.entities.Content;
import fa.trainning.entities.Member;
import fa.trainning.services.ContentService;
import fa.trainning.services.MemberService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

@WebServlet(name = "ServletUpdateContent", value = "/ServletUpdateContent")
public class ServletUpdateContent extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (ContentService service = new ContentService()) {
            HttpSession session = request.getSession(false);
            assert session != null;
            Member memberSession = (Member) session.getAttribute("member");

            int id = Integer.parseInt(request.getParameter("id"));
            int member_id = Integer.parseInt(request.getParameter("member_id"));

            if (memberSession.getMemberID() != member_id) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("_error.jsp");
                dispatcher.forward(request, response);
            } else {
                String content_title = request.getParameter("title");
                String content_brief = request.getParameter("brief");
                String content_main = request.getParameter("content");
                Content content = new Content(id, content_title, content_brief,content_main);
                service.editContentService(content);
                RequestDispatcher dispatcher = request.getRequestDispatcher("/ServletViewAllContent?id="+ member_id);
                dispatcher.forward(request, response);
            }
        } catch (ParseException
                | ServletException
                | IOException
                | SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
