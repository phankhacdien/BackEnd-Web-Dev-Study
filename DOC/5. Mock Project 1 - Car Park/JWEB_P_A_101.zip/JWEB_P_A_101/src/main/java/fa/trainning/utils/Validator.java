package fa.trainning.utils;

public class Validator {
}
