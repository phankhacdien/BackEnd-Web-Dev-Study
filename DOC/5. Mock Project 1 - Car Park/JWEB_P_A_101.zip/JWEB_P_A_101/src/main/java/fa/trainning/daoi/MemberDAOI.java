package fa.trainning.daoi;

import fa.trainning.entities.Member;
import java.sql.SQLException;
import java.text.ParseException;

public interface MemberDAOI {
    Member checkLogin(String email, String password) throws SQLException, ClassNotFoundException;
    boolean registerMember(Member member)  throws SQLException, ClassNotFoundException, ParseException;
    boolean updateMember(Member member) throws SQLException, ClassNotFoundException, ParseException;
    Member viewMemberById(int memberId) throws SQLException, ClassNotFoundException, ParseException;
    boolean getMemberByEmail(String email) throws SQLException, ClassNotFoundException, ParseException;
}
