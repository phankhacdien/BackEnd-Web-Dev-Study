package fa.trainning.controller.memberServlet;

import fa.trainning.entities.Member;
import fa.trainning.services.MemberService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

@WebServlet(name = "ServletMemberEdit", value = "/ServletMemberEdit")
public class ServletMemberEdit extends HttpServlet {
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    try (MemberService memberService = new MemberService()) {
      int id = Integer.parseInt(request.getParameter("id"));
      HttpSession session = request.getSession(false);
      assert session != null;
      Member memberSession = (Member) session.getAttribute("member");
      if (memberSession.getMemberID() != id) {
        RequestDispatcher dispatcher = request.getRequestDispatcher("_error.jsp");
        dispatcher.forward(request, response);
      } else {
        Member member = memberService.viewMemberByIdService(id);
        request.setAttribute("member", member);
        request.setAttribute("id", id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("edit-profile.jsp");
        dispatcher.forward(request, response);
      }
    } catch (ParseException
        | ClassNotFoundException
        | ServletException
        | IOException
        | SQLException e) {
      e.printStackTrace();
    }
  }

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    doGet(request, response);
  }
}
