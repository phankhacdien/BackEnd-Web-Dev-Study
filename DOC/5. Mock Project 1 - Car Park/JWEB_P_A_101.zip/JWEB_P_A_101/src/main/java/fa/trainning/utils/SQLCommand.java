package fa.trainning.utils;

public class SQLCommand {
    public static final String MEMBER_QUERY_LOGIN =
        "SELECT * FROM [dbo].[Member] WHERE [Member].[Email] = ? AND [Member].[Password] = ?";
    public static final String CONTENT_QUERY_CREATE =
        "INSERT INTO [dbo].[Content]\n"
            + "    ([Title], [Brief],[ContentMain], [MemberID], [CreatedDate], [UpdateTime])\n"
            + "VALUES\n"
            + "    (?,?,?,?, CONVERT(VARCHAR(10), getdate(), 111), CONVERT(VARCHAR(10), getdate(), 111));";
    public static final String MEMBER_QUERY_REGISTER =
        "INSERT INTO [dbo].[Member]\n"
            + "    ([UserName], [Password], [Email], [CreatedDate], [UpdateTime])\n"
            + "VALUES\n"
            + "    (?,?,?, CONVERT(VARCHAR(10), getdate(), 111), CONVERT(VARCHAR(10), getdate(), 111));";
    public static final String CONTENT_QUERY_GET_ALL =
        "SELECT [Content].[ContentID], [Content].[Title],[Content].[Brief],[Content].[CreatedDate]\n"
            + "FROM [dbo].[Content]\n"
            + "INNER JOIN [dbo].[Member]\n"
            + "ON [Content].[MemberID] = [Member].[MemberID]\n"
            + "WHERE [Member].[MemberID] = ?;";
    public static final String MEMBER_QUERY_UPDATE =
        "UPDATE [dbo].[Member]\n"
            + "SET [Member].[FirstName] = ?,[Member].[LastName] = ?, [Member].[Phone]=?, [Member].[Description]=?, [Member].[UpdateTime]=CONVERT(VARCHAR(10), getdate(), 111)\n"
            + "WHERE [Member].[MemberID] =?;";
    public static final String MEMBER_QUERY_VIEW_BY_ID =
        "SELECT [MemberID], [FirstName], [LastName], [UserName], [Password], [Phone], [Email], [Description], [CreatedDate], [UpdateTime] from [dbo].[Member] " +
              "WHERE [Member].[MemberID] = ?";
    public static final String CONTENT_QUERY_DELETE_BY_ID =
        "DELETE FROM [dbo].[Content] WHERE [Content].[ContentID]=?;";
    public static final String CONTENT_QUERY_EDIT_BY_ID =
            "SELECT [Content].[ContentID], [Content].[Title],[Content].[Brief], [Content].[ContentMain]" +
                    "FROM [dbo].[Content]" +
                    "WHERE [Content].[ContentID] = ?";
    public static final String CONTENT_QUERY_UPDATE_BY_ID =
            "UPDATE [dbo].[Content]\n" +
                    "SET [Content].[Title] = ?,[Content].[Brief] = ?,[Content].[ContentMain] = ?,[Content].[UpdateTime]= CONVERT(VARCHAR(10), getdate(), 111)" +
                    "WHERE [Content].[ContentID] =?;";
    public static final String MEMBER_QUERY_GET_BY_EMAIL =
            "SELECT [UserName], [Password], [Email] from [dbo].[Member] " +
                    "WHERE [Member].[Email] = ?";
}