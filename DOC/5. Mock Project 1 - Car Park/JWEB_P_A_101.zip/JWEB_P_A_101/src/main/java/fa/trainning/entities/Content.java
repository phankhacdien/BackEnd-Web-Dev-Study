package fa.trainning.entities;

import java.sql.Date;

public class Content {
    private int contentId;
    private String title;
    private String brief;
    private String content;
    private Date createdDate;
    private Date updateTime;
    private int authorId;

    public Content() {
    }

    public Content(int contentId, String title, String brief, String content) {
        this.contentId = contentId;
        this.title = title;
        this.brief = brief;
        this.content = content;
    }

    public Content(int contentId, String title, String brief, Date createdDate) {
        this.contentId = contentId;
        this.title = title;
        this.brief = brief;
        this.createdDate = createdDate;
    }

    public Content(String title, String brief, String content, int authorId) {
        this.title = title;
        this.brief = brief;
        this.content = content;
        this.authorId = authorId;
    }

    public Content(String title, String brief, String content, Date createdDate, Date updateTime, int authorId) {
        this.title = title;
        this.brief = brief;
        this.content = content;
        this.createdDate = createdDate;
        this.updateTime = updateTime;
        this.authorId = authorId;
    }

    public Content(int contentId, String title, String brief, String content, Date createdDate, Date updateTime, int authorId) {
        this.contentId = contentId;
        this.title = title;
        this.brief = brief;
        this.content = content;
        this.createdDate = createdDate;
        this.updateTime = updateTime;
        this.authorId = authorId;
    }

    public int getContentId() {
        return contentId;
    }

    public void setContentId(int contentId) {
        this.contentId = contentId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBrief() {
        return brief;
    }

    public void setBrief(String brief) {
        this.brief = brief;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public int getAuthorId() {
        return authorId;
    }

    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Content{");
        sb.append("contentId=").append(contentId);
        sb.append(", title='").append(title).append('\'');
        sb.append(", brief='").append(brief).append('\'');
        sb.append(", content='").append(content).append('\'');
        sb.append(", createdDate=").append(createdDate);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", authorId=").append(authorId);
        sb.append('}');
        return sb.toString();
    }
}
