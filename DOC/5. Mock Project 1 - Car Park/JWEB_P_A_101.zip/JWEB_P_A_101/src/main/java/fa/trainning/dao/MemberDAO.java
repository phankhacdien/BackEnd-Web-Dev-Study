package fa.trainning.dao;

import fa.trainning.common.DBUtils;
import fa.trainning.daoi.MemberDAOI;
import fa.trainning.entities.Member;
import fa.trainning.utils.ErrorHandling;
import fa.trainning.utils.SQLCommand;

import java.sql.*;
import java.text.ParseException;

public class MemberDAO implements MemberDAOI, AutoCloseable {
    private Connection connection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet results = null;
    DBUtils dbhelper = DBUtils.getDBHelper();

    @Override
    public Member checkLogin(String email, String password) throws SQLException, ClassNotFoundException {
        Member member = null;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.MEMBER_QUERY_LOGIN);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            results = preparedStatement.executeQuery();
            if (results.next()) {
                member = new Member();
                member.setMemberID(results.getInt("MemberID"));
                member.setFirstName(results.getString("FirstName"));
                member.setLastName(results.getString("LastName"));
                member.setUserName(results.getString("UserName"));
                member.setPhone(results.getString("Phone"));
                member.setEmail(email);
                member.setDescription(results.getString("Description"));
                member.setCreatedDate(results.getDate("CreatedDate"));
                member.setUpdateTime(results.getDate("UpdateTime"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        return member;
    }

    @Override
    public boolean registerMember(Member member) throws SQLException, ParseException {
        boolean check = false;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.MEMBER_QUERY_REGISTER);
            preparedStatement.setString(1, member.getUserName());
            preparedStatement.setString(2, member.getPassword());
            preparedStatement.setString(3, member.getEmail());
            check = preparedStatement.executeUpdate() > 0;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        return check;
    }

    @Override
    public Member viewMemberById(int memberId) throws SQLException, ClassNotFoundException, ParseException {
        Member member = null;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.MEMBER_QUERY_VIEW_BY_ID);
            preparedStatement.setInt(1, memberId);
            results = preparedStatement.executeQuery();
            if (results.next()) {
                member = new Member();
                member.setMemberID(results.getInt("MemberID"));
                member.setFirstName(results.getString("FirstName"));
                member.setLastName(results.getString("LastName"));
                member.setUserName(results.getString("UserName"));
                member.setPhone(results.getString("Phone"));
                member.setEmail(results.getString("Email"));
                member.setDescription(results.getString("Description"));
                member.setCreatedDate(results.getDate("CreatedDate"));
                member.setUpdateTime(results.getDate("UpdateTime"));
            }
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return member;
    }


    @Override
    public boolean updateMember(Member member) throws SQLException, ClassNotFoundException, ParseException {
        boolean check = false;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.MEMBER_QUERY_UPDATE);

            preparedStatement.setString(1, member.getFirstName());
            preparedStatement.setString(2, member.getLastName());
            preparedStatement.setString(3, member.getPhone());
            preparedStatement.setString(4, member.getDescription());
            preparedStatement.setInt(5, member.getMemberID());
            check = preparedStatement.executeUpdate() > 0;
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return check;
    }

    @Override
    public boolean getMemberByEmail(String email){
        boolean check = false;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.MEMBER_QUERY_GET_BY_EMAIL);
            preparedStatement.setString(1, email);
            results = preparedStatement.executeQuery();
            check = results.next();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        return check;
    }


    @Override
    public void close() {
    }
}
