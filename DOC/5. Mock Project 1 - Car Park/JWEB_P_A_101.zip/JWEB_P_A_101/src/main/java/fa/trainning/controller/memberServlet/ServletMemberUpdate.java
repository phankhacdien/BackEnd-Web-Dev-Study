package fa.trainning.controller.memberServlet;

import fa.trainning.entities.Member;
import fa.trainning.services.MemberService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ServletMemberUpdate", value = "/ServletMemberUpdate")
public class ServletMemberUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (MemberService service = new MemberService()) {
            int memberId = Integer.parseInt(request.getParameter("id"));
            String firstName = request.getParameter("firstName");
            String lastName = request.getParameter("lastName");
            String phone = request.getParameter("phone");
            String description = request.getParameter("description");
            Member member = new Member(memberId, firstName, lastName, phone, description);
            service.updateMemberService(member);

            RequestDispatcher dispatcher = request.getRequestDispatcher("/ServletMemberEdit?id="+memberId);
            dispatcher.forward(request, response);
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
