package fa.trainning.controller.contentServlet;

import fa.trainning.entities.Content;
import fa.trainning.entities.Member;
import fa.trainning.services.ContentService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

@WebServlet(name = "ServletCreateContent", value = "/ServletCreateContent")
public class ServletCreateContent extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (ContentService contentService = new ContentService()) {
            HttpSession session = request.getSession(false);
            assert session != null;
            Member memberSession = (Member) session.getAttribute("member");
            int id = Integer.parseInt(request.getParameter("id"));

            if (memberSession.getMemberID() != id) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("_error.jsp");
                dispatcher.forward(request, response);
            } else {
                String content_title = request.getParameter("title");
                String content_brief = request.getParameter("brief");
                String content_main = request.getParameter("content");

                Content newContent = new Content(content_title, content_brief, content_main, id);
                contentService.createContentService(newContent);
            }

        } catch (ParseException
                | ServletException
                | IOException
                | SQLException throwables) {
            throwables.printStackTrace();
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/ServletViewAllContent");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }


}
