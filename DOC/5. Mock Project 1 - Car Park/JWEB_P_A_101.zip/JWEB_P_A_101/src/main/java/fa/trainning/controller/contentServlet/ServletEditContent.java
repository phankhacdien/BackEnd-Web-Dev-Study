package fa.trainning.controller.contentServlet;

import fa.trainning.entities.Content;
import fa.trainning.services.ContentService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ServletEditContent", value = "/ServletEditContent")
public class ServletEditContent extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (ContentService contentService = new ContentService()) {
            int id = Integer.parseInt(request.getParameter("id"));
            Content existingContent = contentService.getContentByIdService(id);
            request.setAttribute("content", existingContent);
            RequestDispatcher dispatcher = request.getRequestDispatcher("add-content.jsp");
            dispatcher.forward(request, response);
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
