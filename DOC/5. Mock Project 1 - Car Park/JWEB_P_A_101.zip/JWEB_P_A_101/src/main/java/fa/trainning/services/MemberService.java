package fa.trainning.services;

import fa.trainning.daoi.DAOFactory;
import fa.trainning.daoi.MemberDAOI;
import fa.trainning.entities.Member;

import java.sql.SQLException;
import java.text.ParseException;

public class MemberService implements AutoCloseable{
    private final MemberDAOI memberDAO = DAOFactory.getNewMemberDAO();


    public boolean registerMemberService(Member member) throws SQLException, ParseException, ClassNotFoundException {
        return memberDAO.registerMember(member);
    }

    public Member viewMemberByIdService(int memberId) throws SQLException, ParseException, ClassNotFoundException {
        return memberDAO.viewMemberById(memberId);
    }
    public boolean updateMemberService(Member member) throws SQLException, ParseException, ClassNotFoundException {
        return memberDAO.updateMember(member);
    }
    @Override
    public void close(){
    }


    public boolean getMemberByEmailService(String email) throws SQLException, ParseException, ClassNotFoundException{
        return memberDAO.getMemberByEmail(email);
    }
}
