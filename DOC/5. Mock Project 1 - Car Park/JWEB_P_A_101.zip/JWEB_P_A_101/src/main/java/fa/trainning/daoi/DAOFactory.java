package fa.trainning.daoi;

import fa.trainning.dao.ContentDAO;
import fa.trainning.dao.MemberDAO;

public class DAOFactory {
    public static ContentDAOI getNewContentDAO() {
        return new ContentDAO();
    }
    public static MemberDAOI getNewMemberDAO() {
        return new MemberDAO();
    }
}
