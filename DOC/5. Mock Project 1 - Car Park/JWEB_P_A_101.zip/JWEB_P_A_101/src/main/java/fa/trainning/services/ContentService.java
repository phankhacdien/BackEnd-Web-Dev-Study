package fa.trainning.services;

import fa.trainning.daoi.ContentDAOI;
import fa.trainning.daoi.DAOFactory;
import fa.trainning.entities.Content;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

public class ContentService implements AutoCloseable{
    private final ContentDAOI contentDAO = DAOFactory.getNewContentDAO();

    public boolean createContentService(Content content)  throws SQLException, ParseException {
        return contentDAO.createContent(content);
    }
    public List<Content> viewAllContentService(int memberID)  throws SQLException, ParseException {
        return contentDAO.viewAllContent(memberID);
    }
    public List<Content> searchContentService(String key, int id)  throws SQLException, ParseException {
        return contentDAO.searchContent(key, id);
    }
    public boolean editContentService(Content content)  throws SQLException, ParseException {
        return contentDAO.editContent(content);
    }
    public boolean deleteContentService(int id)  throws SQLException, ParseException {
        return contentDAO.deleteContent(id);
    }

    public Content getContentByIdService(int id)  throws SQLException, ParseException{
        return contentDAO.getContentById(id);
    }

    @Override
    public void close() {
    }


}
