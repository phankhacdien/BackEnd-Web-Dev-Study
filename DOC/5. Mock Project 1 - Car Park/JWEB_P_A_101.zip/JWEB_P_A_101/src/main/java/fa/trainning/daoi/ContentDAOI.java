package fa.trainning.daoi;

import fa.trainning.entities.Content;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

public interface ContentDAOI {
    boolean createContent(Content content) throws SQLException, ParseException;
    List<Content> viewAllContent(int memberID) throws SQLException, ParseException;
    List<Content> searchContent(String key, int id) throws SQLException, ParseException;
    boolean editContent(Content content) throws SQLException, ParseException;
    boolean deleteContent(int id) throws SQLException, ParseException;
    Content getContentById(int id) throws SQLException, ParseException;
}
