package fa.trainning.dao;

import fa.trainning.common.DBUtils;
import fa.trainning.daoi.ContentDAOI;
import fa.trainning.entities.Content;
import fa.trainning.utils.SQLCommand;
import fa.trainning.utils.ErrorHandling;

import java.sql.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class ContentDAO implements ContentDAOI {
    private Connection connection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet results = null;
    DBUtils dbhelper = DBUtils.getDBHelper();


    @Override
    public boolean createContent(Content content) throws SQLException, ParseException {
        boolean check = false;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.CONTENT_QUERY_CREATE);
            preparedStatement.setString(1, content.getTitle());
            preparedStatement.setString(2, content.getBrief());
            preparedStatement.setString(3, content.getContent());
            preparedStatement.setInt(4, content.getAuthorId());
            check = preparedStatement.executeUpdate() > 0;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        return check;
    }

    @Override
    public List<Content> viewAllContent(int memberId) throws SQLException, ParseException {
        List<Content> contents = new ArrayList<>();
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.CONTENT_QUERY_GET_ALL);
            preparedStatement.setInt(1,memberId);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ContentID");
                String title = rs.getString("Title");
                String brief = rs.getString("Brief");
                Date createdDate = rs.getDate("CreatedDate");
                contents.add(new Content(id, title, brief, createdDate ));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        return contents;
    }

    @Override
    public boolean editContent(Content content) throws SQLException, ParseException {
        boolean check = false;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.CONTENT_QUERY_UPDATE_BY_ID);

            preparedStatement.setString(1, content.getTitle());
            preparedStatement.setString(2, content.getBrief());
            preparedStatement.setString(3, content.getContent());
            preparedStatement.setInt(4, content.getContentId());

            check = preparedStatement.executeUpdate() > 0;
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return check;
    }

    @Override
    public boolean deleteContent(int id) throws SQLException, ParseException {
        boolean rowDeleted = false;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.CONTENT_QUERY_DELETE_BY_ID);
            preparedStatement.setInt(1,id);
            rowDeleted = preparedStatement.executeUpdate() > 0;
        }catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        return rowDeleted;
    }

    @Override
    public Content getContentById(int id) throws SQLException, ParseException {
        Content content = null;
        try {
            connection = dbhelper.getConnection();
            preparedStatement = connection.prepareStatement(SQLCommand.CONTENT_QUERY_EDIT_BY_ID);
            preparedStatement.setInt(1, id);
            results = preparedStatement.executeQuery();
            if (results.next()) {
                content = new Content();
                content.setContentId(results.getInt("ContentID"));
                content.setTitle(results.getString("Title"));
                content.setBrief(results.getString("Brief"));
                content.setContent(results.getString("ContentMain"));
            }
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return content;
    }

    @Override
    public List<Content> searchContent(String key, int id) throws SQLException, ParseException {
        List<Content> contents = new ArrayList<>();
        try {
            connection = dbhelper.getConnection();
      preparedStatement =
          connection.prepareStatement(
              "SELECT [Content].ContentID, Content.Title, Content.Brief, Content.CreatedDate FROM [dbo].[Content] WHERE \n"
                  + "([Content].[ContentMain] LIKE '%"+key+"%'\n"
                  + "OR [Content].[Title] LIKE '%"+key+"%'\n"
                  + "OR [Content].[Brief] LIKE '%"+key+"%')\n"
                  + "AND [Content].[MemberID] = "+id+";");
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int memberId = rs.getInt("ContentID");
                String title = rs.getString("Title");
                String brief = rs.getString("Brief");
                Date createdDate = rs.getDate("CreatedDate");
                contents.add(new Content(memberId, title, brief, createdDate ));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                ErrorHandling.printSQLException(e);
            }
        }
        for (Content content: contents){
      System.out.println(content.toString());
        }
        return contents;
    }
}
