package fa.trainning.controller.contentServlet;

import fa.trainning.entities.Content;
import fa.trainning.entities.Member;
import fa.trainning.services.ContentService;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

@WebServlet(name = "ServletViewAllContent", value = "/ServletViewAllContent")
public class ServletViewAllContent extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (ContentService contentService = new ContentService()) {
            HttpSession session = request.getSession(false);
            assert session != null;
            Member memberSession = (Member) session.getAttribute("member");
            int id = Integer.parseInt(request.getParameter("id"));

            if (memberSession.getMemberID() != id) {
                RequestDispatcher dispatcher = request.getRequestDispatcher("_error.jsp");
                dispatcher.forward(request, response);
            } else {
                List<Content> listContent = contentService.viewAllContentService(id);
                request.setAttribute("listContent", listContent);
                RequestDispatcher dispatcher = request.getRequestDispatcher("view-content.jsp");
                dispatcher.forward(request, response);
            }
        } catch (ParseException
                | ServletException
                | IOException
                | SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
