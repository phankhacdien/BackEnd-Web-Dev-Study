package fa.trainning.controller.memberServlet;

import fa.trainning.dao.MemberDAO;
import fa.trainning.entities.Member;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "ServletMemberLogin", value = "/ServletMemberLogin")
public class ServletMemberLogin extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String destPage;
        MemberDAO memberDAO = new MemberDAO();

        try {
            Member member = memberDAO.checkLogin(email, password);
            destPage = "login.jsp";
            if (member != null) {
                HttpSession session = request.getSession();
                session.setAttribute("member", member);
                destPage = "ServletViewAllContent?id="+ member.getMemberID();
            } else {
                String message = "Invalid email/password";
                request.setAttribute("message", message);
            }

            RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
            dispatcher.forward(request, response);

        } catch (SQLException | ClassNotFoundException ex) {
            throw new ServletException(ex);
        }
    }
}
